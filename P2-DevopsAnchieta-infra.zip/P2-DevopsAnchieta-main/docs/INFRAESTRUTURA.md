# Infraestrutura — o que foi feito e por quê

Resumo para o grupo apresentar a parte de Infraestrutura e Documentação.

## Docker

| Serviço | Imagem | Porta | Detalhes |
|---|---|---|---|
| `db` | `postgres:16-alpine` | 5432 | Volume `barbearia_postgres_data` mantém os dados; healthcheck com `pg_isready`. |
| `api` | `backend/Dockerfile` | 3000 | Build multi-stage: etapa 1 compila TypeScript, etapa 2 leva só `dist/` e dependências de produção. Roda como usuário `node` (não root). Healthcheck em `GET /`. Só inicia quando o banco está saudável. |
| `frontend` | `frontend/Dockerfile` | 8080 → 80 | Nginx servindo os arquivos estáticos. Ao iniciar, gera `js/config.js` com a variável `API_URL`, então a mesma imagem serve para qualquer ambiente. |

Ordem de inicialização garantida por `depends_on` + `condition: service_healthy`: **db → api → frontend**.

## Correções feitas no código para rodar no Docker

1. **Maiúsculas/minúsculas nos imports.** Os arquivos estavam salvos como `errorhandler.ts`, `apperror.ts`, `barbeiroroutes.ts` etc., mas eram importados como `errorHandler`, `AppError`, `barbeiroRoutes`. O Windows ignora essa diferença; o Linux (dentro do container e no GitHub Actions) não, e a API nem compilava. Os imports foram ajustados para o nome real dos arquivos.
2. **`await import('../models')` → `require('../models')`** em `config/database.ts`: o TypeScript recusava o build com `module: Node16`.
3. **Opção `DB_SSL`** em `config/database.ts`, necessária para bancos na nuvem.
4. **Swagger** (`swagger-ui-express`) em `/docs`, especificação em `src/docs/swagger.ts`.
5. **Frontend:** `js/config.js` incluído antes de `js/api.js`; `getApiBaseUrl()` usa a URL digitada na tela, senão `config.js`, senão `localhost:3000`.
6. `backend/docker-compose.yml` foi substituído pelo `docker-compose.yml` da raiz (agora com os três serviços).
7. `.gitattributes` força quebra de linha LF em `.sh`, `Dockerfile` e `.conf` (scripts com CRLF quebram no Linux).

## Testes realizados

Com a API compilada e um PostgreSQL 16 real: cadastro de barbeiro e cliente, login (JWT), criação de serviço, disponibilidade, consulta de horários livres, agendamento criado e **segundo agendamento no mesmo horário recusado (409)**, listagem de barbeiros e Swagger respondendo em `/docs`.

## Pendências observadas (fora da infraestrutura — para o backend)

- **Autorização por perfil (critério 6):** as rotas só verificam se há token válido. Hoje um barbeiro consegue criar agendamento em nome de um cliente, e qualquer usuário logado pode criar serviço para outro barbeiro. Sugestão: usar `res.locals.usuario.id`/`tipo` em vez de `barbeiroId`/`clienteId` do corpo da requisição.
- Não há rota para o barbeiro **confirmar** agendamento (só cancelar).
- `preco` volta como texto (`"45.00"`) por ser `DECIMAL` no PostgreSQL; o frontend deve converter com `Number()`.
