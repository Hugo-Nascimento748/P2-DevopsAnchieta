# Publicação (deploy)

Objetivo (critério 9 do escopo): frontend e API publicados, comunicando-se pela internet, sem depender do computador de nenhum integrante.

| Parte | Onde | Custo |
|---|---|---|
| Frontend | GitHub Pages | Gratuito |
| API + banco | Render (Docker + PostgreSQL) | Plano free |

> O plano gratuito do Render "dorme" após ~15 min sem uso: a primeira requisição pode levar ~1 min. Abra a API alguns minutos antes da apresentação. O banco free do Render expira após 30 dias — suficiente para a entrega.

## 1. API e banco no Render

1. Crie uma conta em https://render.com entrando com o GitHub.
2. **New → Blueprint** e selecione este repositório. O Render lê o `render.yaml` e cria:
   - `barbearia-db` (PostgreSQL);
   - `barbearia-api` (Docker, pasta `backend/`), com `JWT_SECRET` gerado e `DATABASE_URL` ligada ao banco.
3. Aguarde o deploy e teste `https://<seu-servico>.onrender.com/docs`.
4. Em **barbearia-api → Settings → Deploy Hook**, copie a URL.
5. No GitHub: **Settings → Secrets and variables → Actions → Secrets → New repository secret**
   - Nome: `RENDER_DEPLOY_HOOK_URL` — Valor: a URL copiada.

A partir daí, todo push na `main` que altere `backend/` publica a API (`deploy-api.yml`).

> Usando outro banco (Neon, Supabase)? Crie a API como **Web Service → Docker** com *Root Directory* `backend`, defina `DATABASE_URL` (URL externa), `JWT_SECRET` e `DB_SSL=true`.

## 2. Frontend no GitHub Pages

1. GitHub: **Settings → Pages → Build and deployment → Source: GitHub Actions**.
2. **Settings → Secrets and variables → Actions → Variables → New repository variable**
   - Nome: `API_URL` — Valor: `https://<seu-servico>.onrender.com` (sem barra no final).
3. **Actions → Deploy do frontend (GitHub Pages) → Run workflow** (ou faça um push em `frontend/`).
4. O endereço aparece no resumo do workflow: `https://<usuario>.github.io/<repositorio>/`.

## 3. Conferência final

- [ ] `https://<api>/docs` abre o Swagger.
- [ ] Site publicado cadastra e faz login (sem o modo "Simular caso API offline").
- [ ] Algo criado pelo Swagger aparece no site após atualizar a página (critério 8).
- [ ] Endereços publicados preenchidos na tabela do topo do `README.md`.
- [ ] Badge/aba **Actions** com os workflows em verde.
