#!/bin/sh
# Gera o arquivo de configuração lido pelo navegador (js/config.js).
# A URL precisa ser acessível pelo NAVEGADOR do usuário (não use o nome "api" do compose).
set -e
cat > /usr/share/nginx/html/js/config.js <<CONF
window.API_BASE_URL = '${API_URL}';
CONF
echo "Frontend configurado para usar a API em: ${API_URL}"
