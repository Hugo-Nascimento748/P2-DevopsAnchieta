/*
 * Configuração do frontend.
 * Este arquivo é sobrescrito automaticamente:
 *  - no Docker, a partir da variável API_URL (docker-compose.yml);
 *  - no GitHub Pages, a partir da variável de repositório API_URL (workflow deploy-frontend.yml).
 */
window.API_BASE_URL = 'http://localhost:3000';
