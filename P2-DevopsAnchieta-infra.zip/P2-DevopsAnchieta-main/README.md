# Sistema de Agendamento para Barbearias

Projeto acadêmico (P2 — DevOps, Anchieta): site para clientes e barbeiros e uma API para autenticação e gerenciamento de agendamentos.

| Ambiente | Frontend | API | Swagger |
|---|---|---|---|
| Local (Docker) | http://localhost:8080 | http://localhost:3000 | http://localhost:3000/docs |
| Publicado | `https://<usuario>.github.io/<repositorio>/` *(preencher)* | `https://<servico>.onrender.com` *(preencher)* | `https://<servico>.onrender.com/docs` *(preencher)* |

## Proposta

Conectar clientes a barbeiros. Clientes consultam barbeiros, serviços e horários livres e solicitam agendamentos. Barbeiros gerenciam serviços, disponibilidade e agendamentos. Escopo completo e critérios de aceite em [`ESCOPO.md`](ESCOPO.md).

## Arquitetura

```
 Navegador ──► frontend (Nginx :8080) ── HTML/CSS/JS estático
     │
     └──────► api (Node.js + Express :3000) ──► db (PostgreSQL 16 :5432)
                 ├─ JWT (autenticação)              └─ volume barbearia_postgres_data
                 ├─ Sequelize (ORM)
                 └─ Swagger em /docs
```

| Pasta / arquivo | Conteúdo |
|---|---|
| `frontend/` | Páginas estáticas, estilos e integração HTTP (`js/api.js`). `js/config.js` define a URL da API. |
| `frontend/Dockerfile`, `frontend/docker/` | Imagem Nginx que serve o site e gera `config.js` a partir da variável `API_URL`. |
| `backend/` | API em TypeScript, Express, Sequelize, PostgreSQL e JWT. |
| `backend/Dockerfile` | Build em duas etapas (compila TS → imagem final enxuta, sem root). |
| `backend/src/docs/swagger.ts` | Documentação OpenAPI exibida em `/docs`. |
| `docker-compose.yml` | Sobe banco + API + frontend com um comando. |
| `.github/workflows/` | CI (build + teste com Docker) e deploy automático (GitHub Pages e Render). |
| `render.yaml` | Blueprint para criar API e banco no Render. |
| `docs/DEPLOY.md` | Passo a passo da publicação. |
| `backend/_archive/legacy-prisma/` | Protótipo antigo com Prisma, só para consulta; não faz parte da aplicação. |

## Executar com Docker (recomendado)

Requisito: [Docker Desktop](https://www.docker.com/products/docker-desktop/) instalado e aberto.

```bash
# 1. Na raiz do projeto, crie o arquivo de variáveis
cp .env.example .env          # Windows PowerShell: copy .env.example .env

# 2. (opcional) edite o .env e troque JWT_SECRET

# 3. Suba tudo
docker compose up -d --build
```

Aguarde ~30 s e acesse:

- Site: http://localhost:8080
- API: http://localhost:3000
- Swagger: http://localhost:3000/docs

Comandos úteis:

| Ação | Comando |
|---|---|
| Ver status dos containers | `docker compose ps` |
| Ver logs da API | `docker compose logs -f api` |
| Parar | `docker compose down` |
| Parar **e apagar o banco** | `docker compose down -v` |
| Recriar após mudar código | `docker compose up -d --build` |
| Abrir o banco no terminal | `docker compose exec db psql -U postgres -d barbearia` |

> Porta ocupada? Altere `DB_PORT`, `API_PORT` ou `FRONTEND_PORT` no `.env`. Se mudar `API_PORT`, ajuste também `API_URL`.

As tabelas são criadas automaticamente pela API ao iniciar (`sequelize.sync`), incluindo as restrições que impedem dois agendamentos no mesmo horário.

## Executar sem Docker (desenvolvimento)

Requisitos: Node.js 22+ e PostgreSQL.

```bash
docker compose up -d db       # ou use um PostgreSQL instalado na máquina
cd backend
npm install
cp .env.example .env          # ajuste DATABASE_URL e JWT_SECRET
npm run dev                   # API em http://localhost:3000 com recarga automática
```

Abra `frontend/index.html` no navegador (ou use a extensão Live Server do VS Code).

## Variáveis de ambiente

| Variável | Onde | Descrição |
|---|---|---|
| `DATABASE_URL` | API | String de conexão do PostgreSQL. No Docker é montada automaticamente. |
| `JWT_SECRET` | API | Segredo para assinar os tokens. **Obrigatório** e diferente em produção. |
| `PORT` | API | Porta da API (padrão 3000). |
| `NODE_ENV` | API | `development` mostra o SQL no log; `production` não. |
| `DB_SSL` | API | `true` para bancos na nuvem que exigem SSL. |
| `API_URL` | Frontend | Endereço da API **acessível pelo navegador**. |
| `POSTGRES_USER` / `POSTGRES_PASSWORD` / `POSTGRES_DB` | Banco | Credenciais criadas no primeiro start. |

## Rotas da API

Documentação interativa completa em **`/docs`** (Swagger). Para testar rotas protegidas: cadastre-se, faça login, copie o `token` e clique em **Authorize**.

| Método | Rota | Autenticação | Descrição |
|---|---|---|---|
| GET | `/` | — | Status da API (healthcheck) |
| POST | `/auth/cadastro` | — | Cadastro de cliente ou barbeiro (`tipo`: `CLIENTE` \| `BARBEIRO`) |
| POST | `/auth/login` | — | Login, retorna JWT (2h) |
| GET | `/auth/perfil` | JWT | Dados do usuário logado |
| GET | `/barbeiros` | JWT | Lista barbeiros e serviços ativos |
| GET | `/barbeiros/:id` | JWT | Detalhe de um barbeiro |
| GET | `/barbeiros/:id/horarios-livres?servicoId=&data=` | JWT | Horários livres no dia |
| GET/POST | `/servicos` | JWT | Lista / cria serviços |
| GET/PUT/DELETE | `/servicos/:id` | JWT | Detalha / edita / desativa serviço |
| GET/POST | `/disponibilidades` | JWT | Lista / cria disponibilidade |
| DELETE | `/disponibilidades/:id` | JWT | Remove disponibilidade |
| GET/POST | `/agendamentos` | JWT | Lista / solicita agendamento |
| PATCH | `/agendamentos/:id/cancelar` | JWT | Cancela agendamento |

## CI/CD (GitHub Actions)

| Workflow | Quando roda | O que faz |
|---|---|---|
| `ci.yml` | Todo push e pull request | Compila a API, sobe o `docker compose` e testa API, Swagger, frontend, cadastro e login. |
| `deploy-frontend.yml` | Push na `main` que altere `frontend/` | Publica o site no GitHub Pages com a URL da API publicada. |
| `deploy-api.yml` | Push na `main` que altere `backend/` | Aciona o deploy da API no Render. |

Configuração única dos deploys: veja [`docs/DEPLOY.md`](docs/DEPLOY.md).

## Problemas comuns

| Sintoma | Solução |
|---|---|
| `port is already allocated` | Outra aplicação usa a porta. Mude a porta no `.env` ou pare o PostgreSQL local. |
| Site mostra "API offline" | Confira `docker compose ps` (API deve estar `healthy`) e se a URL da API na tela é `http://localhost:3000`. |
| Mudei o código e nada mudou | Rode `docker compose up -d --build`. |
| Quero zerar o banco | `docker compose down -v` e suba de novo. |
| `40-config-api.sh: not found` no frontend | O script foi salvo com quebra de linha do Windows (CRLF). O `.gitattributes` evita isso; converta o arquivo para LF. |

## Integrantes

| Nome | RA | Responsabilidade |
|---|---|---|
| *(preencher)* | | Backend |
| *(preencher)* | | Frontend |
| *(preencher)* | | Infraestrutura e documentação |
